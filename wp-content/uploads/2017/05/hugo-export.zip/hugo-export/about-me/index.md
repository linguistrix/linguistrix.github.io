---
title: Antariksh’s Blog | About Me
author: Antariksh
type: page
date: 2012-03-26T12:59:07+00:00
seo_follow:
  - 'false'
seo_noindex:
  - 'false'
dsq_thread_id:
  - 785649257

---
<p style="text-align: left;">
  <a href="http://i0.wp.com/www.antarikshbothale.com/wp-content/uploads/2012/03/AntTentsPassP.jpg"><img class="alignright wp-image-899" src="http://i0.wp.com/www.antarikshbothale.com/wp-content/uploads/2012/03/AntTentsPassP.jpg?resize=192%2C189" alt="Antariksh Bothale" srcset="http://i0.wp.com/www.antarikshbothale.com/wp-content/uploads/2012/03/AntTentsPassP.jpg?resize=300%2C295 300w, http://i0.wp.com/www.antarikshbothale.com/wp-content/uploads/2012/03/AntTentsPassP.jpg?w=707 707w" sizes="(max-width: 192px) 100vw, 192px" data-recalc-dims="1" /></a>Hi! This is Antariksh Bothale. I finished my Dual Degree in Mechanical Engineering from IIT Bombay. After working as a consultant with A.T. Kearney at Mumbai, I joined the University of Washington at Seattle for an <span style="line-height: 1.5em;">MS in Computational</span> Linguistics. I was a Research Scientist Intern at <a href="http://www.amazon.com/" target="_blank">Amazon</a> in the summer of 2014, and am now working at <a href="http://www.bloomreach.com/" target="_blank">Bloomreach</a>. I live in California.
</p>

Among other things, I am passionate about languages and linguistics, and also maintain a blog on the same—<a href="http://www.linguistrix.com/blog" target="_blank">Linguistrix</a>.

I love exploring new fields and learning about them. These days, I am getting into gardening, and learning to play the piano. These come close on the heels of a motley group of interests such as cooking, typography, photography and the US Interstate System. Given the vastness of the world, there&#8217;s enough to keep me busy 🙂

As far as online networking goes, I am mostly active on Facebook (and FB Messenger), with very occasional posts on Twitter. I used to be quite active on Quora, but have not posted there in quite a while. I also have a <a href="https://plus.google.com/101980114326589203228/" rel="me author">Google+ profile</a>, though it&#8217;s also pretty barren. If you wish to get in touch with me, the best way would be to send an email (<name>.<surname>@gmail.com).

If you wish to subscribe to my posts/updates, you can use any of the following buttons:



<span class="quora-follow-button" data-name="Antariksh-Bothale">Follow <a href="http://www.quora.com/Antariksh-Bothale">Antariksh Bothale</a> on <a href="http://www.quora.com">Quora</a></span> <a class="twitter-follow-button" href="https://twitter.com/antarikshB" data-show-count="false">Follow @antarikshB</a>