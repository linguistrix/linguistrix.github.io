---
title: Packing List
author: Antariksh
type: page
date: 2017-03-17T01:15:55+00:00
draft: true
private: true

---
This packing list was originally made in 2009 and intended for college students from India who go abroad for internships or similar medium-length stays (~3 months). For students moving to the US for graduate school or any other long stay, read the notes.

There is a printable compact version of the [packing list][1] I made.

Notes: Quantities are merely suggestive. The list is aimed at being extensive so that you can use it as a checklist to ensure you&#8217;re not missing anything. Almost everything you&#8217;d need can be purchased in most major cities around the world, so customize this based on your specific money, weight and volume constraints.

## Clothes

<li style="font-weight: 400;">
  <span style="font-weight: 400;">Jeans / Trousers (4+)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Shirts / T-Shirts (8+)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Shorts / Sweatpants / Joggers etc. (2+)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Undergarments (At least a week&#8217;s worth preferable)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Towels (2), Napkins / Hand towels (if needed)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Formal Clothing (1 pair, if not included above)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Handkerchiefs, Socks </span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Shoes / chappal / floaters etc.</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Accessories: Belt, Jewelry, Watches</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Drawstring / Naada for salwaars / pajaamas (also useful for packing / as a makeshift clothesline)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Warm Jacket(s) (Waterproof, depending on weather)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">Woolens&#8212;Thermal inners, Sweaters, Gloves, Cap, Mufflers (if cold)</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">\textsf{Traditional wear}</span>
</li>
<li style="font-weight: 400;">
  <span style="font-weight: 400;">\textsf{Formal shoes}</span>
</li>

 [1]: http://www.antarikshbothale.com/docs/PackingList.pdf