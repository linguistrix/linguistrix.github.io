---
title: To Freshies
author: Antariksh
type: post
date: 2012-09-16T18:27:24+00:00
url: /to-freshies/
dsq_thread_id:
  - 846756715
categories:
  - Articles

---
Originally, this post was supposed to be a retrospective post about college. I took those elements and condensed them into a few things that I&#8217;d want to say to the new batch at IIT. Of course, there&#8217;s nothing batch-specific about this post, so I invite everyone to read and comment. These points are not necessarily the most important things freshies should know, but these are those which usually never get told.

## **Eschew Department Stereotypes**

Ever since the day you came to know about your branch allocation, you must have been inundated by pointless, irrelevant and often wrong feedback about your department. It will worsen now that you are in IIT, with every other guy commenting on your branch selection and passing along traditional wisdom. If you’ve taken a low-ranking branch despite getting a high rank, you’d be called stupid. If you’ve opted for Dual Degree when your rank allowed you to choose BTech, you’d be called stupid. If you let it be known that you intend to do research in ‘Meta’, you’d be called stupid. You will realize that, as a freshie, it’s very easy to be called stupid.

It’s also equally devoid of content. By giving in to department stereotypes, you not only straitjacket yourself, you fall prey to years of unfounded prejudice. Choosing Meta is not stupid—but whiling the first two semesters away because you were told ‘Meta is a lukkha branch’ is. Obviously, branch does matter. All men may be created equal, but all branches certainly are not, which makes it all the more important that you have a realistic idea about your branch, instead of swallowing recycled stereotypical trash hook, line, and sinker. Mind you, I encourage you to seek an idea about the prospects of your branch and to plan out your IIT life accordingly, but make sure you get this from well-informed folks.

Department stereotypes are self-fulfilling prophecies—people tell you there are no future prospects in X branch, and you spend your IIT life resigned to this fatality, while wiser people go ahead, pursue those prospects, and get them.

Eschew Department Stereotypes.

## **Look for full disclosure** 

As freshies, you would find yourself at the receiving end of advice, suggestions, opinions, recommendations and what not from a wide variety of people (including, rather ironically, from me, through this post). Develop the judgment to figure out whose opinion to take on a particular matter. It is very rare that you’d encounter a person who could give you valuable advice across a large and diverse array of fields. The guy who gives you excellent dating advice won’t necessarily give you great foreign-internship fundae. And the guy who you trust your deepest secrets with might give you lousy advice about which elective to take.

Also, look for full disclosure. Often, a lot of what people would tell you would be tainted with what’s good for them instead of what’s good for you. Did the hostel sports secy just tell you it’s not necessary to study for next day’s Maths Quiz because he wanted you to go cheer for the Hostel Water Polo team? Did a CG/Manager just tell you CPI doesn’t matter? Did your neighbourhood 10 pointer just tell you extra-currics are useless? No one really wishes you bad (for the most part), but that doesn’t mean you take in everything they say without scrutinizing it and looking for full disclosure.

I find it funny when the only credential juniors offer about a piece of info/opinion is _&#8220;Kisi senior ne bola hai&#8221;_. Don’t have “One Stop Seniors”. At IIT, you’d find yourself part of a group of brilliant people. Everyone’s different, and unique. There&#8217;s a huge wealth of experience to tap into. Talk to everyone, but take a smart call about who you would trust best for what.

Look for full disclosure.

## **Have Fun with Acads**

IIT(B) is not Three Idiots; it is not Rang De Basanti; it is not Main Hoon Na. In fact, it isn’t anything like the stereotyped mush that Bollywood (and other mainstream media) feeds you under the all-inclusive heading _college life_.

A common motif in most colleges, and IITB is no different, is a fashionably cavalier attitude towards academics. It’s a screwed up system where not only is it OK to not study, it’s actually socially desirable. Instead of going into a hatred spiral where you teach yourself to not give a fuck about academics, try to look at courses and subjects as something potentially interesting. Obviously, neither all courses nor all professors will be fun, but you’ll be surprised at how much the quality of your experience would improve if you treat academics with slightly more openness.

Ask questions. Interact. Maybe read up a bit. It won’t need a change in your schedule. Just your attitude.

Don’t suck up to profs.  But carry an ounce of empathy.

Have Fun with Acads.

&nbsp;

And have a great time at IIT.

<img src="http://i2.wp.com/www.linguistrix.com/blog/wp-content/uploads/2012/05/antsmall.png" alt="" data-recalc-dims="1" />