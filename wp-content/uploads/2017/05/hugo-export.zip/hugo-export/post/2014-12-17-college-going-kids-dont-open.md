---
title: Why your college-going kids don’t open up to you
author: Antariksh
type: post
date: 2014-12-17T21:51:21+00:00
url: /college-going-kids-dont-open/
dsq_thread_id:
  - 3334653022
categories:
  - Articles
  - Quora Answers

---
This answer was originally posted on <a href="https://www.quora.com/I-think-my-college-going-son-is-being-very-selective-in-what-he-chooses-to-share-with-me-What-should-I-do/answer/Antariksh-Bothale" target="_blank">Quora</a>. The question was:

> <div id="ld_mlilqz_4772">
>   <a id="__w2_XwB4nz0_link" class="question_link" href="https://www.quora.com/I-think-my-college-going-son-is-being-very-selective-in-what-he-chooses-to-share-with-me-What-should-I-do" target="_self"><span class="link_text">I think my college-going son is being very selective in what he chooses to share with me. What should I do?</span></a>
> </div>

<div id="ld_mlilqz_4773">
  <div class="question_details">
    <div id="__w2_u1nQNlF_inline_editor_content" class="InlineEditor QuestionDetailsInlineEditor inline_editor_content hover">
      <blockquote>
        <div id="__w2_n5RH3iz_text_snip" class="expanded_q_text">
          <span id="__w2_n5RH3iz_text_snip_content">I only come to know of certain things AFTER they happen, and that too if they are happy news &#8211; news I can only be happy as a reaction for. Apart from news, nothing. I don&#8217;t know what emotions he goes through, what his concerns are, what his dreams are.</span>
        </div>
      </blockquote>
    </div>
  </div>
</div>

I understand it would hurt to feel so disconnected with your son. While I cannot fix this directly, I&#8217;d try and help you with potential reasons why this might be so, and you could introspect a bit about whether they apply to you. Now, just to clarify, although I&#8217;d appear to be blindly favoring your college-going son, I am no apologist for our generation. I don&#8217;t think we are blessed with exceptional intelligence or insight—far from that, we are winging it, like everyone else.

I am going to talk about three things: **Conflict**, **Autonomy** and **Escalation**

# Conflict

Most people take the path of least resistance; they will tell you whatever lies you need to hear in order to minimize the conflict in everyone&#8217;s life. What lies you get depends on what conflicts you mutually create. Sample this:

> **_Instance 1: (Son is out having dinner with his friends. His dad calls him)_**
  
> **Dad**: _Kya kar raha hai?_ (What are you doing?)
  
> **Son**: _Dinner karne aaya hoon baahar._ (I’ve stepped out for dinner)
  
> **Dad**: _Jab dekho baahar ghoomta aur khata rahta hai. Mess hai na tere yahaan?_ (I see you going out all the time. You have messing facilities in the hostel, right?)

&nbsp;

> **_Instance 2: (Son is out having dinner with his friends. His dad calls him)_**
  
> **Parent**: Kya kar raha hai? (What are you doing?)
  
> **Son**: Kuchh nahin, mess mein dinner kar raha hoon (I’m having dinner in the mess)
  
> **Parent**: _Yeh gaane ki aawaaz kahaan se aa rahi hai peechhe se_ (Why do I hear music in the background?)
  
> **Son**: _Wo… side mein lounge mein dance practice chal rahi hai&#8230;_ (Erm, they have a dance practice session in the lounge)

The truth is that you cannot realistically control every single living moment of your children&#8217;s lives, especially not when they become adults themselves. So you have to resign yourself to the fact that they are going to do what they want to anyway. If you frequently express disapproval of their activities (in some cases, your disapproval may be justified, but that doesn&#8217;t matter), they will probably just stop telling you about what they do.

If it creates conflict or unnecessary headache or drama, it will be avoided. For instance, if your first reaction on hearing that your son has a girlfriend is one of anger (or worse: OMG! You have a girlfriend? No kissing! Get married soon!), you are pretty much guaranteeing that your son will never talk to you about his love life.

Ultimately, unreasonable or excessive expectations are not going to be met with compliance. They are going to be met with defiance and deception. The question is, do you want them to live lives so secret that you don&#8217;t even know them as persons any more, or do you want to actually be connected with who they really are? If you want to be a part of their lives, you&#8217;d have to relax a bit on trying to judge and control them.

Note that this does not even need to be directed to your kid. If you make disapproving remarks about your neighbor&#8217;s son getting a girlfriend, be assured your son is going to hide his from you. If, for instance, you made homophobic remarks while watching a movie or flipping through news channels reporting about 377, you can bask in the assurance that your gay son will never come out to you.

Now, this is obviously not easy. After all, your values are not merely a fashion statement. You hold them because you, to a large extent, sincerely believe in them and subscribe to them. But every generation rebels. 30 years ago, people might have prided themselves for having a &#8216;love marriage&#8217;. Many youngsters today take that to be the bare minimum.

These differing versions of morality across generations aren&#8217;t new, but it is possible that the chasm has widened due to the much more increased exposure that our generation gets. You will have to resign yourself to the fact that your kid may live a life vastly different from yours.

# Autonomy

If you made your child grow up with a lot of rules and restrictions, subjecting their lives to unnecessary or excessive scrutiny, there is a good chance that they will want to break free of it all at the first available opportunity. This is also why being overly protective is problematic—you are only creating a recipe for rash and irresponsible decision-making later, making them rush to make use of whatever autonomy they get, because they have been bottling up their frustration for so long.

If you try to be too nosy or try to micro-manage their lives, they will initiate micro-rebellions. For instance, although they _could_ tell you that they are going to Marine Drive with their friends, they&#8217;d choose NOT to, because that gives them a sense of self-control, of autonomy, and of not being constantly monitored or policed.

Ironically, the more you try to be a <a id="qlink_k0" class="qlink" href="http://en.wikipedia.org/wiki/Helicopter_parent" data-link-delete="http://en.wikipedia.org/wiki/Helicopter_parent">helicopter parent</a> of someone who is essentially an adult, the more likely you are to become distant from them. Someone I know had such helicopter parents. She worked in a different city, but they&#8217;d try to remote control everything she did, everywhere she went, and so on. Did it stop her from doing what she wanted? Obviously not, but it did encourage her to create an elaborate web of lies about her actions and movement. Whose gain was it?

# 

# Escalation

How do you behave when your son does share something unpleasant with you? Do you go paranoid, or enter panic mode, or go just plain ballistic? If so, you are strongly disincentivizing him from sharing anything with you. There&#8217;s a reason friends are often perfect for sharing your fears or worries or insecurities—they are sufficiently close to you without being so close as to take everything extremely personally.

People share stuff for different reasons. Some just want someone to confide in who can process the information relatively calmly, not necessarily a problem solver. If you get emotional or teary eyed or livid at the shortest provocation, your kid will avoid telling you unpleasant stuff, as telling it increases the problems in his life rather than easing them.

<div>
  <hr />
</div>

The 20s are a difficult time for all of this. People have to make the mental transition from _needing_ their parents to potentially _being needed_ by them. While school-going kids are taught to see parents as infallible authority figures, as captors who need to be defied, young adults have to slowly learn to see parents as more human, with their own hopes and aspirations, fears and insecurities. Between these two extremes is the territory most late teens and early 20s find themselves in, wherein they feel the need to assert their independence and gain footing in the world without being tethered to their parents.

I don&#8217;t intend to tell you that your kid is perfectly capable of taking all life decisions wisely. It is likely that he makes several bad decisions. But irrespective of whether he is or not, he is past the age where you can micro-manage his life. Just like the younger generation, you should also try and choose your battles, intervening only for stuff that merits intervention. (Hint: Haircut doesn&#8217;t qualify)

Needless to say, none of this is easy, and I&#8217;m obviously no expert, but I hope I did manage to shed some light on what you could potentially do to make it slightly less difficult.