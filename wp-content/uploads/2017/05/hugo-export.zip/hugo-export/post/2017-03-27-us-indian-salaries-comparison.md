---
title: US and Indian Salaries, a Comparison
author: Antariksh
type: post
date: -001-11-30T00:00:00+00:00
draft: true
url: /?p=926
categories:
  - Articles

---
Every year, the month of December sees a media circus around campus job placements—the mainstream media makes a huge deal out of &#8216;pay packages&#8217; with unrealistic numbers, adding up bonuses and stock payments and what-not and reporting it as annual income, leading to news reports and telecasts about &#8216;1.5 crore packages&#8217;.

More than the  stress they already face during the placement process (and in general, during their stay at IIT). Unrealistic expectations also create a general atmosphere of general panic and discontent.

On the other end, people trying to fight against this problem sometimes tend to go towards the other extreme. I remember that a journalist I talked to a couple of years ago when my post had become moderately viral on FB seemed keen on somehow proving that, at the end of the day, once you had done all the PPP-arithmetic and normalization and what not, salary packages in America and India were more or less equivalent.

Starting out with a mission to somehow equate salaries / life in the US with that in India seems to me as perverse as adding every possible number to arrive at a giant annual salary figure.

* * *

A common motif in discussions that try to balance these salary scales is the claim that living in America (and in general, in most developed countries) is pretty expensive. This is followed by examples about how a kg of potatoes would set you back by 100 rupees, and so on.

As someone who&#8217;s previously lived in Germany, Canada and Japan on relatively modest student budgets (and with the added constraint of saving some of the stipend for travel and (if possible) for spending in India), and has traveled to other countries for short durations, I can definitely attest that when you spend in these countries, the

&nbsp;

  * Most material luxuries (and often, even necessities) are more affordable in the US than in India
  * Most services are typically more affordable in India