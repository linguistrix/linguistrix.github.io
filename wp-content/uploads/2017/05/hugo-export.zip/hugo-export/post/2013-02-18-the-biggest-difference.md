---
title: The biggest difference
author: Antariksh
type: post
date: 2013-02-18T11:47:31+00:00
url: /the-biggest-difference/
dsq_thread_id:
  - 1090384623
categories:
  - This Life

---
In a very beautifully written article (<a id="qlink_kb4sx8skry" href="http://www.yaledailynews.com/news/2012/may/27/keegan-opposite-loneliness/" data-link-delete="http://www.yaledailynews.com/news/2012/may/27/keegan-opposite-loneliness/" data-link-text="KEEGAN: The Opposite of Loneliness">KEEGAN: The Opposite of Loneliness</a>), (Late) Marina Keegan, then a final year student at Yale, said:

> We don’t have a word for the opposite of loneliness, but if we did, I could say that&#8217;s what I want in life. What I’m grateful and
  
> thankful to have found at Yale, and what I’m scared of losing when we wake up tomorrow and leave this place.
> 
> It’s not quite love and it’s not quite community; it’s just this feeling that there are people, an abundance of people, who are in this together. Who are on your
  
> team. When the check is paid and you stay at the table. When it’s four a.m. and no one goes to bed. That night with the guitar. That night we can’t remember. That time we did, we went, we saw, we laughed, we felt. The hats.

And this is what the biggest difference for me has been after leaving IIT. Most of the &#8216;material&#8217; things can be easily replaced. You can get fairly fast Internet even outside IIT, for instance. You&#8217;ll almost certainly have a better standard of living too. But it&#8217;s difficult to get back the opposite of loneliness.

When you&#8217;re in a residential college, &#8216;hanging out&#8217; just happens. You stay in a wing with 20 people who you&#8217;ve grown with and who&#8217;ve grown up with you, and there are hundreds more in close proximity who you can reach in a jiffy. You are all in it together. Batch-mates, seniors, juniors, with their lives all tied together by countless invisible threads.

In college, when you want to hang out, you drop by someone&#8217;s room.

When you are outside, it&#8217;s not so straightforward. Schedules need to be matched. Plans need to be made. Traffic and transit times need to be accounted for. For virtual hangouts, you have to make sure everyone&#8217;s free in their respective time-zones.  There might be friends who don&#8217;t mind hanging out but will never initiate anything themselves, and you might occasionally feel whether you&#8217;re the only one who cares. You&#8217;re still &#8216;hanging out&#8217;, but now it&#8217;s this distinct activity, and you set it off from other activities of your life, such as &#8216;work&#8217;. There&#8217;s no more the spontaneity of just dropping into someone&#8217;s room because you were bored of studying for the midsems, or taking a quick stroll to the canteen or the juice center at midnight, or the warm comfort of just being with people you love in a collective space that you all truly consider your own, and I am not talking of Mumbai&#8217;s chawls.

Now, I understand that the opposite of loneliness isn&#8217;t something everyone cherishes equally. If you&#8217;re the quiet, introvert type, it&#8217;s perfectly understandable that you&#8217;d find the constant flux of humanity that you encounter in college pretty tiresome. But even then, I imagine you&#8217;d also have a small comfort group who&#8217;d always be easily accessible and whose company you&#8217;d not find easily once you get out of college.

Without the easy lubrication of proximity, it can get difficult to keep relationships well tuned. You may find many conversations starting and ending with elementary courtesies and niceties._ (What&#8217;s up man? Long time! Yeah, nothing much. Job life. What&#8217;s up with you? Same here)._ It&#8217;s not that friendships have weaned. It&#8217;s just that distance makes every interaction a task in itself, and distances can sometimes be good but harsh litmus tests for which people matter the most to you.

Don&#8217;t take me wrong. I don&#8217;t intend to paint an unnecessarily dark story, and it&#8217;s really not as gloomy as it may sound. A lot of us might have felt this way even when we left school and made our way into college. At least I did, but we made new friends and most of us now consider our college days to be the best days of our life. So, it&#8217;s not gloomy at all. We&#8217;d soon stop missing college. We&#8217;d enter new relationships. We&#8217;d marry. We&#8217;ll surely move on. Humans are fairly resilient that way.

But every once in a while, I will crave the easy comfort of the opposite of loneliness.

[This answer was originally <a href="http://www.quora.com/Indian-Institutes-of-Technology/What-differences-does-one-feel-after-leaving-an-IIT/answer/Antariksh-Bothale" target="_blank">posted here</a> on Quora]