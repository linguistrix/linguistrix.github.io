---
title: Stupid analogies are like stupid analogies
author: Antariksh
type: post
date: 2012-01-16T17:26:40+00:00
url: /stupid-analogies-are-like-stupid-analogies/
s2mail:
  - yes
seo_follow:
  - 'false'
seo_noindex:
  - 'false'
dsq_thread_id:
  - 785880622
categories:
  - Articles

---
I have always had a love-hate relation with analogies, though it has mostly veered towards hate. I agree that they can occasionally be illuminating and can make difficult concepts more palatable, but I have often considered them evil and felt that they do more harm than good. Usually, they over-simplify a concept to &#8220;dumb it down&#8221;, so to speak, but end up creating easy-to-kill straw-men, or make arguments go into a tangent just because people start arguing over the analogy instead of the original premise. Also, I feel they sometimes fail to achieve their purpose—which was providing a meaningful insight into the issue at hand. If I understand a concept well, I would be able to appreciate the analogies that can be drawn from it. I would also have the necessary insight to understand places where the analogy would fail. However, all this is fairly opaque to the person at whom that analogy was aimed, so it often defeats the purpose. This is especially so because it is extremely rare that an analogy maps with the original bijectively. Usually, an analogy connects only a few aspects of both situations, and that too in a fairly tenuous fashion. And if your listeners try to over-explore an analogy, it just ends up backfiring.

I am particularly wary of analogies that are part of school teaching. Plenty of the Sanskrit shlokas and Hindi dohe rely on analogies to bring home the point, but the way they are taught, the analogies are used for justification rather than exposition, which is just plain wrong. Of course, I realize the value of these pithy sayings/couplets/expressions/etc. so I am not objecting to them—all I am saying is that I prefer to keep analogies at arm&#8217;s length in discussions and arguments.

A particularly delicious abuse of analogies is the whole animal analogy business—a treacherous (and highly convenient) ground to base your argument on. It works both ways, so you can use it irrespective of which side of the argument you are on. There&#8217;s always an animal analogy out there. Sample this—

**Premise: Humans are like animals.**

_Argument: Dogs don&#8217;t discriminate on the basis of breed! Why should we discriminate on the basis of caste?_

Never mind the fact that no one would even question this bullshit. What do you know about whether dogs discriminate on the basis of _breed_ or not? I don&#8217;t know much about dogs, but I suspect that an Alsatian won&#8217;t usually have sex with a Pomeranian (unless, of course, it&#8217;s getting bored or something). Should that be considered as animal casteism? Should humans refuse to procreate with people from other races because dogs apparently do the same? It&#8217;s just pile upon pile of stupidity made to look profound.

**Premise: Humans are not like animals.**

****_Argument: Dogs have no problem having sex in the open. That doesn&#8217;t mean humans should start doing the same!_

Dude, settle it once and for all whether or not humans should look at dogs as models for emulation.  Note that you can&#8217;t resort to circular arguments claiming that &#8216;_discrimination is bad, hence humans shouldn&#8217;t definitely do it if even animals aren&#8217;t doing it_ &#8216;.  &#8216;Discrimination is wrong&#8217; was supposed to be the conclusion, not the explanation. If your audience could have understood that at face value, you won&#8217;t have needed a stupid animal analogy.

I could use the humans-are-like-animals argument to say that it is OK for men to kill weaker men while looking for a suitable mate, and I could use the humans-are-not-like-animals to claim that it is OK for men to kill for pleasure. Both are stupid arguments, but the animal analogy didn&#8217;t shed any light on them. In fact, it made them worse.

This is why I hate them in serious discussions—they are argument-crutches. What sounds like a cool analogy is often just a way to cover up shitty arguments and get rid of the burden of serious proof.  Deep-seated issues such as those of ethics, morals, &#8216;freedom&#8217; etc. cannot be solved by animal analogies, and heck, can&#8217;t even be understood using animal analogies. You need to face the problem in its entirety, and you have to face it on its home ground. It&#8217;s tough, yes, but it&#8217;s the only real solution. Otherwise you have idiots who will claim that contraception is bad because it is unnatural (!) and that gay marriage is wrong because it is unnatural. How about I claim that polygamy, adultery and cannibalism are OK because all three are found among animals? Animals have been known to have sex forcibly. Does that mean rape is natural? These analogy-toting idiots don&#8217;t spend even one minute on any actual justification. They get away with bullshitting about nature.

In some ways, this worse than bullshit, which I use here to mean _content-less blather that is so convoluted that its truth value is difficult to evaluate, and which was never even intended to convey a particular truth value_. That&#8217;s because while BS makes you look like an idiot, analogies make you look smart and witty and profound, thus ridding you of the burden of proof and giving your audience a false sense of awe and understanding. It helps you get an upper hand in an argument without actually making a great deal of sense.

I often hear arguments which treat human languages and programming languages as practically the same thing, and freely try to justify and rationalize their opinions and assertions regarding human languages by giving analogies with computer languages. Leaving aside the sheer audacity of someone comparing something as deep, complex and intensely fascinating as human language with something that pales several orders of magnitude in front of it (I speak from a pretty objective viewpoint), the simple fact is that such an analogy is highly untenable, and is almost always likely to derail the argument.