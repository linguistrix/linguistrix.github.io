---
title: The paradox of arranged marriages
author: Antariksh
type: post
date: 2012-03-26T13:18:17+00:00
url: /the-paradox-of-arranged-marriages/
seo_follow:
  - 'false'
seo_noindex:
  - 'false'
dsq_thread_id:
  - 785807413
categories:
  - Tuppence

---
Interesting stuff has been going on in the country in the last two days. On one end, we have the case of an NGO called Bhrashtachar Nivaran Sanstha threatening to file a suit against producer Sajid Nadiadwala for the item number Anarkali Disco Chali in his movie Houseful 2. The NGO feels that the line, &#8220;Oye hoye chod chaad ke apne Saleem ki gali, Anarkali disco chali&#8230;&#8221; from the song could have a negative impact on children. I wonder how an organization named Bhrashtachar Nivaran Sanstha (Corruption Prevention Organization) finds itself so hopelessly jobless in a country like India, but this whole affair is so retarded that I won&#8217;t comment on it further.

<p style="text-align: center;">
  <span class="embed-youtube" style="text-align:center; display: block;"></span>
</p>

In more interesting news, the Delhi High Court said that a marriage without sex is insipid. Surprise!

It upheld the divorce petition of a man who claimed that his wife was not interested in having a normal sexual relationship with him and denied sex to him even on the first night of their marriage.

To me, this whole thing demonstrates a) the paradoxical nature of purely arranged marriages and b) the extremely problematic terrain of viewing marriages as anything more than civil unions.

The mere discussion of sex complicates matters. For one, you have to start talking in hushed voices. This gives the entire conversation a conspiratorial tone, which is not helped by the fact that no-one wants their personal lives being discussed by middle-aged women as they chop vegetables in the kitchen or sip mocktails at fund-raisers.

At one end, you aren’t supposed to be have pre-marital or extra-marital sex (what will the aunties and the neighbours say!). Given this social scenario, sex deserves to be an integral part of marriage, because that’s the only way you can get some. But, while society expects people to have sex only within marriage and only with one person, it doesn’t seem to give a lot of weight to whether prospective partners would be willing to enter into such an intimate relationship with each other. The only really important things, of course, are whether the planets aligned well at the time of their birth, whether the parents have cheap Maruti 800s are less cheap Maruti Altos, whether they have air-conditioners or desert coolers, and so on. I am not claiming that economic and social status should be irrelevant while deciding who to marry with, but I find it surprising that desirability and sufficient interaction before marriage are never considered all that vital.

In absence of that groundwork, expecting (thereby socially forcing) a woman (or a man) to have sex with a complete stranger right on the first day of marriage not only seems silly, it seems to go against all established protocols of social intercourse. All this made sense when marriage was purely for political and economic reasons, but it doesn&#8217;t seem to hold a lot of ground in today&#8217;s world.

But questioning long-established norms is seen as an adverse effect of ‘Foreign Cultures’. While we are quick to reject intrusions into our &#8216;culture&#8217;, we don&#8217;t pause to think about the loopholes in our cultures that these intrusions expose.