---
title: Cinemagraphs, Day 2
author: Antariksh
type: post
date: 2011-06-29T05:06:32+00:00
url: /cinemagraphs-day-2/
jabber_published:
  - 1309323996
  - 1309323996
email_notification:
  - 1309323996
  - 1309323996
dsq_thread_id:
  - 785893683
categories:
  - Creative
tags:
  - cinemagraph

---
If you have seen my earlier post, [Cinemagraphs, Day 1][1], you must have gotten a hang of what Cinemagraphs are. Well, we went on another shoot, this time stepping out of campus. We wanted more classy locations this time, so Ajay Koli and I went to HN which was the closest. The journey wasn&#8217;t without problems, however. The Crossword guy just won&#8217;t let us shoot inside, and random security personnel started questioning us when we tried to shoot near a fountain. However, the guys at CCD were rather generous; they let us loiter around for about an hour before deciding that _yahaan photo naheen kheench sakte_. I think he would let us if we had ordered another cappuccino but we had already gotten whatever we wanted to. Then we took one in China House (Galleria). I managed to get another shot at Marine Drive. The common problem, however, was that we couldn&#8217;t use a tripod because people start troubling you then.

[<img class="alignnone size-full wp-image-122" title="HorseLight" src="http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/horselight.gif?resize=600%2C338" alt="" data-recalc-dims="1" />][2]

[<img class="alignnone size-full wp-image-121" title="Chicken" src="http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/chicken.gif?resize=600%2C338" alt="" data-recalc-dims="1" />][3]

[<img class="alignnone size-full wp-image-120" title="StirTea" src="http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/stirtea.gif?resize=600%2C338" alt="" data-recalc-dims="1" />][4]

<img class="size-full wp-image-115 alignleft" title="Chalak" src="http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/chalak1.gif" alt="" data-recalc-dims="1" />

 [1]: http://www.antarikshbothale.com/cinemagraphs-day-1/ "Cinemagraphs, Day 1"
 [2]: http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/horselight.gif
 [3]: http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/chicken.gif
 [4]: http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/stirtea.gif