---
title: A parent’s guide to understanding their kids’ salaries
author: Antariksh
type: post
date: 2014-12-03T16:24:34+00:00
url: /parents-guide-understanding-kids-salaries/
dsq_thread_id:
  - 3286979861
categories:
  - Articles
tags:
  - iit
  - iitb
  - jobs
  - packages
  - placements
  - salaries

---
<a href="http://www.antarikshbothale.com/docs/iit_salaries.pdf" target="_blank">Click here to access a PDF version of the Hindi text</a>.

### Hindi Version (English version follows)

पिछले कुछ दिनों से आप अख़बारों में और टीवी पर IIT के छात्र-छात्राओं को मिली नौकरियाँ और उनकी तनख्वाह  के बारे में काफी पढ़-सुन रहे होंगे. 1 करोड़, 1.5 करोड़ जैसे आंकड़े सुन कर आपके ज़हन में भी यही ख़याल आ रहा होगा: कैसे मिलती हैं इस तरह की नौकरियाँ? और क्या आपके बच्चे भी इसी तरह की कोई खबर ले कर आएंगे?

प्लेसमेंट का वक़्त सभी के लिए काफ़ी तनावपूर्ण होता है. लोग खुद को इंटरव्यू वगैरह की तैयारियों और सब की उम्मीदों से पैदा हए बोझ के बीच दबा हुआ महसूस करते हैं. ऐसे में आप उनकी स्थिति समझ कर और अपने बर्ताव को उसके अनुसार ढाल कर उनकी काफी मदद कर सकते हैं.

इस ही सन्दर्भ में प्रस्तुत हैं कुछ तथ्य:

  * संस्थान के Placement Cell के माध्यम से मिली नौकरियों के लिए तन्ख्वायें प्लेसमेंट की प्रक्रिया प्रारम्भ होने के पहले ही तय की जाती हैं. यह शुरुआती तन्ख्वायें मूलतः कंपनी की प्रतिष्ठा कैसी है और काम क्या है / किस तरह का है, इस पर निर्भर करती है, न कि विद्यार्थी की प्रतिभा पर. किसी और से तुलना करते समय इस बुनियादी बात का ख़याल ज़रूर रखें.
  
    मिसाल के लिए, McKinsey या A.T. Kearney जैसी कंसल्टिंग कंपनी के साथ भारत में काम करने वाला कॉलेज से निकला एक शख़्स जहाँ औसतन साल के 15 लाख रुपये तक कमा सकता है, वहीं Goldman Sachs जैसी कंपनी में Quantitative Analyst की भूमिका में उस ही शख़्स के पास इसका दोगुना कमाने का अवसर होगा. चूँकि अलग-अलग कंपनियाँ अलग-अलग तरह के लोग खोजती हैं, और लोगों का भी अलग-अलग तरह की नौकरियों की तरफ रुझान होता है, तो उन सब में से आप किस में चयनित होंगे, यह आपके व्यक्तित्व और रूचि पर निर्भर करता है.
  * कंप्यूटर साइंस के अलावा अधिकांश नौकरियाँ जिनमें इंजीनियरिंग की पढ़ाई का प्रयोग होता है, उनमें आम तौर पर कंसल्टिंग या बैंक वाली नौकरियों से काफी काम पगार होती है. अगर मैकेनिकल इंजीनियरिंग के छात्र-छात्राओं को अपनी पढाई से जुड़े हुए क्षेत्रों में नौकरी करनी है तो शायद उन्हें 10 लाख से कम ही पगार मिले.
  * इसी प्रकार, मैनजमेंट से जुडी हुई नौकरियों में सहसा तकनीकी नौकरियों से ज़्यादा पगार मिलती हैं. यह आपने अपने ऑफिस वगैरह में भी देखा होगा, जहाँ प्रमोशन और वेतन में बढ़ोतरी के साथ साधारणतः मॅनेजरियल ज़िम्मेदारियों में इज़ाफ़ा होता है.
  * अमरीका वगैरह की कम्प्यूटर साइंस वाली कम्पनियाँ (जैसे की गूगल, फ़ेसबुक वगैरह) आम तौर पर अपने पैकेज में तीन तरह की चीज़ें शामिल करती हैं: बेस सॅलरी, साइनिंग बोनस, और स्टॉक. 
      * साइनिंग बोनस (6-7 लाख) नौकरी शुरू करते समय एक बार मिलता है और विदेश जाने और वहाँ बसने के खर्च में मदद करता है
      * स्टॉक या शेयर नौकरी शुरू करने के एक साल बाद मिलना शुरू होते हैं, और 4-5 साल की अवधि में धीरे-धीरे दिए जाते हैं, अगर आप कंपनी में कार्यरत रहें. इनका मूल्य शेयर बाज़ार के उतार-चढ़ाव के हिसाब से बदलता रहता है
      * बेस सैलरी, या तनख़्वाह, जो महीना दर महीना मिलती है, वो आमतौर पर 60-70 लाख सालाना होती है. इस पर 30-35% आयकर भी लगता है.
  * अखबारों को आंकड़ें बढ़ा-चढ़ा कर छापने की आदत होती है. आमतौर पर वे तनख्वाह के साथ-साथ बोनस और शेयर / स्टॉक वगैरह के मूल्य को जोड़कर और इस संख्या को डॉलर से रूपय में तब्दील करने के लिए 60 से गुणा कर के छापते हैं और इसे वार्षिक वेतन की तरह पेश करते हैं, जो सरासर ग़लत है और सिर्फ़ पढ़ने वालों को बहकाने का काम करता है.
  * गौरतलब है की अमरीका जैसे देशों में रोज़मर्रा का खर्च भी काफी ज़्यादा होता है. मिसाल के तौर पर, गूगल फ़ेसबुक जैसी कंपनियों में काम करने के लिए आपको जहाँ रहना पड़ेगा, वहाँ का मासिक किराया ही 1 लाख रूपय तक हो सकता है. खाने बाहर जाएँ तो सस्ती जगहों पर भी 600-1000 रूपए लग जाते हैं. ये सच है की सभी चीज़ों को मद्देनज़र रख कर भी अमरीका में आपकी जीवन-शैली और स्तर शायद भारत की तुलना में बेहतर होंगे, पर दोनों के बीच का अंतर इतना नहीं है जितना अखबारों में पढ़ कर महसूस होता है.
  * साथ ही साथ, यह बहुचर्चित पैकेज कुछ गिनती भर की ही कंपनियाँ के द्वारा दिए जाते हैं, और वो भी कुछ गिनती भर ही के पदों के लिए. यह भी ध्यान रखना ज़रूरी है की अधिकांश IITian जो भारत में नौकरी करते हैं, वे 10-12 लाख सालाना से कम की तनख्वाह से ही अपना करियर शुरू करते हैं.

यह सब पढ़ कर अगर आप निराश महसूस कर रहे हैं तो दोबारा सोचिये. एक अच्छे कॉलेज से होने की वजह से IIT के छात्र-छात्राओं के पास कई ज़्यादा जॉब सिक्यूरिटी होती है. वे चाहे कैसा भी काम करें, उन्हें कभी गुज़र-बसर की चिंता नहीं करनी पड़ेगी, और वे अपनी ज़िन्दगी खुशहाली से बिता पाएंगे. इस निर्भीकता में बहुत बड़ी शक्ति है, क्योंकि इससे उन्हें पैसों वगैरह की फ़िक्र किये बिना अपने ज़िन्दगी के फ़ैसले लेने की आज़ादी मिलती है. अख़बारों में आप जिन नई कंपनियों और स्टार्ट-अप के बारे में पढ़ते हैं, ये वही छात्र शुरू कर पाते हैं, जो नौकरी और पैकेज से बंधे नहीं रहते. फ़ेसबुक, जिसके द्वारा दिया गया ओफ़र मीडिया में अभी चर्चा में आया था, एक 20 साल के युवक ने शुरू किया था. गूगल 2 पीएचडी छात्रों के शोध का नतीजा था.

यह सब लिखने का उद्देश्य आपको प्लेसमेंट से जुड़ी कुछ बारीकियों से आपको अवगत कराना था. प्लेसमेंट का दौर बहुत ही तनावपूर्ण होता है और सामजिक और पारिवारिक दबाव की वजह से बहुत लोग ऐसी नौकरियों में घुस जाते हैं जिनमें उनकी कोई दिलचस्पी नहीं. नौकरियों से असंतुष्ट होकर उन्हें 3-4 महीनों में छोड़ना अब काफ़ी आम हो गया है. अगर आप ऐसे समय में मीड़िया को नज़रअंदाज़ करके और पैकेज की चिंता न करते हुए अपने बच्चों की स्थिति समझेंगे और उनका साथ देंगे तो न सिर्फ उनकी हौसला अफ़ज़ाई होगी, बल्कि वे शायद खुले दिमाग से बेहतर फैसले भी ले पाएंगे.

### English Version:

As you read front-page news articles of IITians being offered salaries of 1.5 crores, you are probably thinking of the same things as many other parents. How does one get such offers? Will your son / daughter get one?

Placement time is an incredibly stressful time for most students, and your behavior and attitude can help improve or worsen their situation significantly.

Here&#8217;s a basic primer.

  * For entry roles in most companies via the college&#8217;s placement cells, salaries are more or less fixed beforehand after negotiation with the placement cell.
  * These salaries offered to new hires depend almost entirely on the industry and/or job profile, and differences in salaries are not so much due to the student&#8217;s talent but more because of their career choice. Bear this in mind when you compare salaries with other parents. For instance, consulting firms such as McKinsey or A.T. Kearney in India typically offer salaries around the 15 lakh per year mark, whereas the same students would have earned more than twice as much if they were working in Quantitative Analysis roles. Also, different companies look for different kinds of individuals, so being selected by one particular kind of company is not an indicator of overall aptitude.**Example:** If Raju&#8217;s mother brings sweets to your house telling you he has been offered 30 lakhs, and is trying to make you feel inferior because your son Sanju was offered only 15 lakh for his consulting job, you can one-up her by telling her that in all likelihood, Raju wasn&#8217;t even shortlisted by consulting firms. [If you do this don&#8217;t tell them I told you to]
  * Apart from Computer Science (CS), most jobs that use core engineering skills are relatively lower paying compared to jobs such as consulting or banking. If someone from Mechanical Engg is interested in working in the field they studied at IIT, it is possible that they will get only a 10 lakh salary. Again, this depends on the choice of career and not necessarily on the aptitude of the student. Likewise, jobs with managerial roles typically pay more than jobs with purely technical roles. You&#8217;d have seen this at your workplace too. Promotion and higher salaries usually come with more managerial responsibilities.
  * In CS companies especially in the US, it is common to offer a signing / joining bonus (usually around $10000, but can be more) and some form of equity (ownership in the company in the form of stocks or something similar). The signing bonus is a one time payment and mostly goes towards covering the costs of relocation. On the other hand, the stock is given over a period of 4 to 5 years, starting a year after joining, which means that the employee starts getting parts of their stock one year after joining, and ends up getting the whole thing at the end of the vesting period if they stay in the company. In effect, the only recurring part of the offer is the base salary, which is typically around $105000 per year for new grads these days.
  * Newspapers have the habit of reporting massive salary figures in the order of crores. First, they add every possible number from the offer letter, including the signing bonuses and the monetary value of the stocks. Second, they just multiply the final figure by 60 and come up with some utterly meaningless number and report it as an annual salary, which is just plain false.
  * It would be helpful to know that the rent one person typically pays in Bay Area is around 75000 to 1 lakh rupees a month, for instance, and a trip to a basic restaurant would cost 600-1000 rupees per head.
  * It is indeed true that despite taking into consideration the higher cost of living in the US and the USD-INR conversion rate, salaries in the US will let you afford a higher overall standard of living than in India, but the difference is not as large as the &#8220;1.4 crore&#8221; figure would convey.
  * Also, these jobs are relatively very few in number, so the chances of getting one are low even if you are good. It would be helpful to note that probably half of IIT graduates get a salary offer of less than 12 lakh.

If you find all this is depressing, think twice. Despite this, by virtue of being from a highly reputed college, your kid has a fair amount of job security. They would never have to worry about day-to-day sustenance. This is extremely enabling, as it lets them make decisions based on factors other than money and instead make their choices more freely. And yet they&#8217;d be able to live comfortably well off no matter what they do. A lot of the startups and businesses you read and hear about are started by students who thought beyond jobs and salaries. Facebook was founded by a 20 year old undergraduate, while Google was born out of the research work of two PhD students. They would value your support in this exploration.

The purpose of telling you all this was to give you a glimpse into the inner workings of placements at IITs. Societal and familial pressures often drive students into accepting jobs they have no interest in. It&#8217;s become extremely common to join jobs and leave them in 3 to 4 months due to dissatisfaction. If you&#8217;d ignore the media, think beyond packages, and try to empathize with your kids as they navigate these tense times, not only will it encourage them, but also potentially enable them to make more prudent decisions. If nothing else, please don&#8217;t make it worse for them by burdening them with unreasonable expectations.