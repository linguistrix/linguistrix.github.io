---
title: The critical mass of goodness
author: Antariksh
type: post
date: 2012-03-24T07:49:07+00:00
url: /the-critical-mass-of-goodness/
s2mail:
  - yes
dsq_thread_id:
  - 785870135
seo_follow:
  - 'false'
seo_noindex:
  - 'false'
categories:
  - Articles
tags:
  - anna hazare
  - corruption
  - critical mass
  - jan lokpal

---
<p style="text-align: left;" align="center">
  The country was galvanized last year by the whole Jan Lokpal Movement, and a lot was said for and against the movement, its leaders and cheerleaders, and the thousands of Indians who poured into the streets in the largest display of public outrage in recent times.
</p>

While we are all fashionably outraged at the way politicians misuse public money with impunity, a small look at the way we lead our daily lives is enough to show that what happens in the order of millions of rupees is just a bigger manifestation of a phenomenon that is integral to our everyday life. We readily pay money to cut corners; we regularly try to cheat the system and feel proud of it. Worse still, we rationalize most of it by telling ourselves that this is all because the system is corrupt—as if multi-million dollar scams in Delhi force us to ask our kids to lie to the ticket-collector about their age.

The problem is that, in India, it’s incredibly unfair to expect otherwise.

Most of the public transport in Germany (and many other countries) works on a self-help basis. You buy tickets and punch them yourselves; if you are carrying pets or bicycles, you buy tickets for them as applicable. There are no ticket-collectors in most trains, nor are there any turnstiles or other setup for verification of tickets. There are occasional spot-checks in trams and buses, but they are few and far between.

It’s tempting to skip buying tickets when simple probability tells you that the expected value of cheating the system is in your favour. Why buy tickets then? To feel that you are doing the right thing? The problem is that doing the right thing can make you feel incredibly stupid. What matters is not whether there are enough ticket-collectors, but whether there are enough commuters around you who buy tickets.

Take the case of a guy who is given a fail grade in a course merely because he didn’t attend enough classes. His friends, who attended fewer lectures than him, have managed to pass through because they asked someone to sign the attendance sheet for them. Alternatively, imagine a student who gets a lower grade than the rest of his class because no one else find anything wrong in cheating in a take-home examination. Or think of the guy who keeps a chocolate wrapper in his pocket while everyone else throws theirs out of the bus window.

The other day, we were standing at one side of a busy road in South Bombay, and were waiting for the pedestrian light to go green. There was a brief period when the road was relatively empty and the vehicle nearest to us was about a hundred metres away. If you wanted to, you could run across the road while the pedestrian light was still red. That’s exactly what everyone did. I hesitated for a second, saw that everyone else in my group had reached the middle of the road, lost the battle with myself, and sprinted. A friend, noticing my hesitation, looked at me incredulously and said—‘oh, you follow traffic rules?’ before quickly adding—‘nahin, matlab acchi baat hai’ _(no no, I mean, that’s a good thing)_.

Before punishing wrong, it’s important to foster a culture where people recognize the wrong. Computer Science students of IIT Bombay learn, right in their second year, that there won’t be any tolerance for plagiarism/cheating/copying of any form, and that punishment would be meted out to both the guy who copies and the guy who wilfully gives his assignment to be copied. Most other departments, on the other hand, are remarkably lax about copying in assignments, and turn a blind eye to even the most blatant instances of the same. They thus foster a culture where copying is not only acceptable, it’s actually desirable. It’s a culture where not letting others copy your assignment brands you as anti-social and unfriendly.

The key then to ensuring goodness is that people who want to do good stuff not be made to feel incredibly stupid for being nice. This is where the critical mass comes in. Once enough people are good, the good ones don’t feel stupid. Once enough people are good, the rest won’t be able to rationalize their badness by referring to collective corruption. Once enough people are good, it would be a nice thing to be good, instead of a stupid thing.

Every once in a while, we hear news reports of a public officer’s life being ruined because he was caught taking a paltry sum as bribe (sometimes as low as INR 300). It’s fun to make sport of such people and to make them face public ignominy. It works beautifully—the ‘higher ups’ can give themselves a pat on the back for ‘exposing corruption’ and punishing it. The holier-than-thou common man who has been taught to feel victimized by corruption smells some kind of sweet revenge. We now have a suspended police officer, and a nation that feels slightly better. Perfect.

When you foster a culture of corruption and then arbitrarily punish a few offenders, you are not being _wrong_ in punishing corrupt people, you’re being irresponsible. The movie ‘Shaitan’ ended with this dialogue:

> सच और सच्चाई में फर्क होता है. हर पुलिस वाले का धर्म है कि वह निःस्वार्थ भाव से इस देश की सेवा करे. लेकिन सच्चाई यह है कि साढ़े-आठ हज़ार की तनख्वाह में देश संभालो, घर संभालो, या ईमान संभालो&#8230; माँ की आँख हो जाती है.

(Paraphrased translation: it’s every policeman’s duty that he serve his country with selflessness. But when you try to take care of your nation, of your family, and of your conscience with a salary of INR 8500… you get fucked up)

Let’s just hope that we can give every policeman and every law-abiding citizen in this country the critical mass of good he needs.