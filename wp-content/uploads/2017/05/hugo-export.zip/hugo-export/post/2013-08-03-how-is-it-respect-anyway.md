---
title: How is it respect anyway?
author: Antariksh
type: post
date: 2013-08-02T19:12:42+00:00
url: /how-is-it-respect-anyway/
dsq_thread_id:
  - 1561353427
categories:
  - Articles

---
Another Bollywood family has come in the media for wrong reasons (or right ones, if you are the blinkered, chest-thumpingly patriotic kind). Puneet Issar&#8217;s wife Deepali Issar <a href="http://articles.timesofindia.indiatimes.com/2013-07-27/news-interviews/40832928_1_issars-young-man-indian-origin" target="_blank">whacked a guy in the theater</a> for allegedly disrespecting the national anthem. In the dialogue, as reported by the ToI, I was particularly amused by the line &#8220;Don&#8217;t lie. You look Indian,&#8221; said by Deepali Issar to the guy who was unfortunate enough to be on the receiving end of her righteous indignation. Turned out he&#8217;s an Australian citizen of Indian origin. On one end we have Delhi policemen who routinely accost people from the North East, calling them _Chinkis_ and treating them as foreigners. And on the other end, we have this.

The issue at hand was of course that the Australian gentleman sat while the National Anthem played on. Worse, he is reported as canoodling with his girlfriend, and everyone knows no Indian likes to see another Indian getting some action. Any action.

But the real issue here is the perverse fascination that Maharashtra has with playing the national anthem before a movie. This is something I have never been able to figure out. I mean, why the hell do you need to play the National Anthem before the start of a movie?!

Countries usually have two kinds of approaches towards their national symbols. For some countries, using the nation&#8217;s flag&#8217;s colors or emblem everywhere is a way of showing love for their country. The maple leaf of Canada can be found everywhere there, including McD Canada&#8217;s logo. In Mauritius, official files are tied with a ribbon that has the four colors of the Mauritian flag. People take pride in associating themselves with the symbols, and wearing an underwear with your flag&#8217;s motif may as well be a sign of patriotism, not of insult. The national anthem&#8217;s tune, or parts thereof, may be used in movies, for example. Pink Panther 1 had a small portion of _La Marseillaise _(French National Anthem), played when Jacques Clouseau makes the press statement about being confident of catching the diamond thief.

The second approach is of course, where you raise national symbols to a sacred level, so sacrosanct that they can&#8217;t be treated as _normal._ India is a perfect example of this category. There is an elaborate _[Flag Code][1]_ that is law-enforced and there are rules about how, when and where to sing or not sing the National Anthem. Using the colors of the flag for design will be frowned upon (and perhaps even punished, depending on the use) and people will tell you off for even humming the national anthem if you do so without being _Petrificus Totallus-_ed. Individuals weren&#8217;t even allowed to display the flag on homes and other buildings until 2001 when Navin Jindal won a court case giving us all that right. All in all, it&#8217;s a strict world here, and we pride ourselves at being excellent watchdogs of our national symbols. And of course, alleged abuses of the same are excellent political _masala_, especially if they involve _kewl_ mass media (MTV tricolor logo case) or mass theism ([Sachin Tendulkar case][2]).

Now, a country might choose whatever approach it wants regarding its symbols, and though I prefer the first one slightly, I am fine with India&#8217;s stance and shall abide by it. This brings me to the simple question—of all places, why does one want to randomly play the National Anthem at the movie hall? Not standing erect while singing it is an insult, but sandwiching it between random movie trailers, advertisements, _dhoomrapaan mana hai _notices and an adult movie apparently isn&#8217;t, and only serves to infuse patriotic sentiments into wayward teens. And while I am on the topic, can someone ask PVR to not show that hideous CGI flag? A more useful thing would be to show the text lyrics in Karaoke style.

I mean, I love the music of our national anthem, and I wish I could sit on my chair and play the National Anthem in the peaceful, dignified, serene setting of my clean room without having neighbors scowling and frowning and calling me unpatriotic or rude. But it seems to me very weird that a country that has a special amendment to explicitly forbid use of the national flag in any clothing below the waist does not find it insulting if the national anthem is played before an adult movie. So much so that we even had a politician fighting to make it compulsory for movie theaters to play the national anthem.

Does anyone see any sensible reason why?

 [1]: http://mahapolice.gov.in/mahapolice/jsp/temp/html/flag_code_of_india.pdf
 [2]: http://timesofindia.indiatimes.com/articleshow/1890038.cms