---
title: The only rules that matter in life
author: Antariksh
type: post
date: -001-11-30T00:00:00+00:00
draft: true
url: /?p=847
categories:
  - Articles

---
The first movie of the _Pirates of the Caribbean_ series has a scene where Jack Sparrow lectures Will Turner about the &#8216;only rules that matter in life&#8217;.

<pre><span class="embed-youtube" style="text-align:center; display: block;"></span></pre>

&#8220;The only rules that really matter are these—,&#8221; Jack says, &#8220;What a man can do and what a man can&#8217;t do.&#8221;

I tend to disagree. An important aspect of growing up, I&#8217;ve realized, is differentiating not so much between the _can-do&#8217;s_ and _can&#8217;t-do&#8217;s_ as between the _can-do&#8217;s_ and the _should-do&#8217;s_.

When we are kids, parents, teachers or other authority figures are quick to divide the world into two annoying but convenient bins of _can-do&#8217;s_ and _can&#8217;t-do&#8217;s. _

&#8220;You can&#8217;t stay up after 10 pm&#8221;

&#8220;You can&#8217;t eat ice-cream more than twice a week&#8221;

&#8220;You can&#8217;t go out in the cold without a jacket on&#8221;

As kids, we hate these restrictions, of course, because they tamper with our freedom. The biggest lure of adulthood for many kids is that it will free them of many such restrictions.

But what we don&#8217;t

This is of course a fairly broad idea, and you can derive many corollaries of it.

Ethics and morality derive largely from this distinction.

&nbsp;

&nbsp;