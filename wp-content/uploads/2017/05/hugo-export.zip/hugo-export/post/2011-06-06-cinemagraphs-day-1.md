---
title: Cinemagraphs, Day 1
author: Antariksh
type: post
date: 2011-06-06T20:56:23+00:00
url: /cinemagraphs-day-1/
jabber_published:
  - 1307393784
dsq_thread_id:
  - 785881360
categories:
  - Creative

---
Cinemagraphs are animated GIFs in which only a small piece of each photograph is animated, making them a neat fusion of still and moving images, somewhat like photographs in the Harry Potter world. This is my first attempt at something like this. The raw videos were taken at 1080p using a Canon EOS 500D and the post-processing was done using Adobe Photoshop CS5 Extended.

(If, for some reason, the images don&#8217;t animate, try Ctrl+F5. If that doesn&#8217;t work, click on the image and open it in a new tab)

Models: Prof. Mandar Inamdar (Civil Engg.)&#8217;s daughter, Mudit Jain, Rajeev Ranka, Sachin Jain

[<img class="alignnone size-full wp-image-80" style="border-color: black; border-style: solid; border-width: 2px;" title="Bottle" src="http://i1.wp.com/antarikshbothale.files.wordpress.com/2011/06/bottles.gif?resize=338%2C600" alt="" data-recalc-dims="1" />][1]

[<img class="alignnone size-full wp-image-82" style="border-color: black; border-style: solid; border-width: 2px;" title="Kid" src="http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/kids.gif?resize=600%2C338" alt="" data-recalc-dims="1" />][2]

[<img class="alignnone size-full wp-image-81" style="border-color: black; border-style: solid; border-width: 2px;" title="Exercise" src="http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/exercises.gif?resize=600%2C338" alt="" data-recalc-dims="1" />][3]

[<img class="alignnone size-full wp-image-83" style="border-color: black; border-style: solid; border-width: 2px;" title="Tennis" src="http://i2.wp.com/antarikshbothale.files.wordpress.com/2011/06/tenniss.gif?resize=600%2C338" alt="" data-recalc-dims="1" />][4]

Also in the act were Akvil, Nikhil and Vikas

 [1]: http://i1.wp.com/antarikshbothale.files.wordpress.com/2011/06/bottles.gif
 [2]: http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/kids.gif
 [3]: http://i0.wp.com/antarikshbothale.files.wordpress.com/2011/06/exercises.gif
 [4]: http://i2.wp.com/antarikshbothale.files.wordpress.com/2011/06/tenniss.gif