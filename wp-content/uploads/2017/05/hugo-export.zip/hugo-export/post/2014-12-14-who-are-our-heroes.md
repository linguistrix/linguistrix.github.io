---
title: Who are our heroes?
author: Antariksh
type: post
date: -001-11-30T00:00:00+00:00
draft: true
url: /?p=770
categories:
  - Articles

---
Who are our heroes?

Over the last few months, I have been mulling over an idea. If I had to condense it into one word, I’d say: **Heroes**.

The heroes of a society reflect its collective ideals. When you know who an individual/group considers a hero, you get a glimpse into what they think is cool… what they would like to do or become themselves.

> Heroes are the personification of our ideals, the embodiment of our highest values. A society writes its diary by naming its heroes. A society writes its diary by naming its heroes. We as individuals do the same. When Socrates said, &#8220;Talk, young man, that I might know you he could have also added, &#8220;Talk of your heroes that I might know not only who you are, but also who you will become.&#8221;

It’s a bit of everything. You could call it culture, if you want.

In his essay _‘Cities and Ambition’_, Paul Graham discusses how different cities give out different kinds of vibes or messages, and how those vibes influence the ambitions of the people living in them.

> Great cities attract ambitious people. You can sense it when you walk around one. In a hundred subtle ways, the city sends you a message: you could do more; you should try harder.
> 
> The surprising thing is how different these messages can be.

A few months ago, a question was posted on Quora about why IIITH continued to produce good quality programmers who routinely secure top spots in programming contests and often beat IIT students. The [top answer][1], written by Yash Kumar, talked about how the culture at IIIT-H is centered on programming. Freshmen year programming courses are considered pretty prestigious there, Yash explains, and success in those courses puts you in good standing in your peer group.

Right from first year, being good at programming is something that makes you cool. This isn’t necessarily so at IITB. You do have great programmers, but no one really talks about them beyond the walls of NSL or the confines of the Web and Coding Club or geeky CS cliques.

At times, it’s unfortunate,

&nbsp;

The Entrepreneurship Cell (ECell) at IITB puts in a lot of effort to spur people into starting up on their own. It’s a commendable effort, but it’ll only truly succeed when entrepreneurs become heroes at IITB. I was discussing this with Nandan (an IITB graduate who’s did his masters from Stanford and now works in the Bay Area), and he mentioned something similar—“Our ‘stud’ seniors are the ones who join good firms or good grad schools for higher studies,” he said, while Stanford’s stud seniors are the “10<sup>th</sup> engineer in Facebook, 3<sup>rd</sup> engineer in Pocket Gems, most of whom are now millionaires at the age of 25.”

When you enter as a freshman, you are surrounded by potential heroes. You are starry-eyed and every hw.

Through a fair mix of CGs and Managers are the heroes. Demi-gods who wield a power that’s

We like to convince ourselves that we are rational beings with

&nbsp;

If your heroes smoke, smoking is colso do you. If your heroes renounce smoking, so will you.

&nbsp;

The ban on smoking was a similar

 [1]: http://www.quora.com/International-Institute-of-Information-Technology-Hyderabad-1/How-does-IIIT-Hyderabad-produce-so-many-world-class-programmers-every-year/answer/Yash-Kumar