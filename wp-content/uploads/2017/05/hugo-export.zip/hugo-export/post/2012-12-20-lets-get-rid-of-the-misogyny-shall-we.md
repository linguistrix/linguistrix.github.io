---
title: Let’s get rid of the misogyny, shall we?
author: Antariksh
type: post
date: 2012-12-19T19:48:29+00:00
url: /lets-get-rid-of-the-misogyny-shall-we/
dsq_thread_id:
  - 983043420
seo_follow:
  - 'false'
seo_noindex:
  - 'false'
categories:
  - Articles

---
It&#8217;s introspection time on both sides of the globe. While America&#8217;s talking (once again) about gun control laws in light of the recent massacre at Sandy Hook Elementary School, India has turned its dial of outrage to the _Women&#8217;s Safety _setting since the last 3 days.

In the last few months, I have had quite a lot of discussion with many people about how women are treated in India. Since it is pretty unlikely that those who are reading this blog are potential rapists, this post is aimed at non-rapists. There is a lot of misogynistic rhetoric that keeps floating around even in well-educated and supposedly modern sections of the society, but no one really thinks it&#8217;s an issue because, well, the Indian threshold for misogyny is rather dismal. Here, I use misogynistic in a slightly relaxed sense. I don&#8217;t intend to say that people hate women. But it&#8217;s important to realize that respecting women involves more than just not raping or molesting them.

You could give several examples, but my favorite (mainly because it&#8217;s so common) is when seniors tell freshies in their facetiously cavalier way that IITian girls aren&#8217;t girls—they&#8217;re at best non-males. Everyone has a laugh, followed by a collective sigh over having the most testosterone-fueled period of one&#8217;s life relegated to a company of andromorphic females. Toilet-humor is common in all-male groups, but I have heard this spoken in very public settings, even on stage with several girls present in the audience.

It&#8217;s a testimony to how widespread this kind of behavior is that no one finds anything wrong with it.

The other day, I was having an argument about this with a friend. He said that most of us respect women and comments such as &#8216;non-male&#8217; were made in jest. He even ventured to suggest that girls probably don&#8217;t even mind it. To that last point my only response was incredulity because I see no reason why any girl wouldn&#8217;t mind what is clearly a very derogatory and insulting remark (I am of course willing to accept the possibility that even girls are now so desensitized by this &#8216;humor&#8217; that they might not only accept it as an unavoidable eventuality, but also propagate it to some extent). I asked him to imagine what he would think if someone insinuated that the only redeeming characteristic about him was that he didn&#8217;t have a vagina. Anyhow, to cross-check, I asked a few girls what they feel about such remarks. Here are two random answers:

> Girls pretend not to mind because it&#8217;s not going to change

> The guy&#8217;s really an ignorant idiot if he thinks girls won&#8217;t mind or won&#8217;t be hurt/upset with such remarks.

It&#8217;s true that most guys around us are largely good at heart, and would really never go as far as sexually molesting a woman, but our responsibility doesn&#8217;t end merely at keeping our dick in our pants. It is easy to forget that rape or assault are only the culmination of a long train of tiny actions or thought-processes that are centered around the basic subconscious idea that women are male property and that the sole purpose of their existence is to be pretty and sexy for men.

An inclusive society isn&#8217;t formed merely by having strict laws or strict enforcement. It&#8217;s formed by starting bottom up, and by fostering a culture where every member of that society can feel welcome and can develop a strong sense of identity, where they can feel comfortable being what they are. Since men have pretty much had a monopoly on the &#8216;forming opinions&#8217; business for a lot of years, it&#8217;s been rather convenient to brand the male way as the standard way.

I find it funny (but thoroughly unsurprising) that while men judge the average woman predominantly and persistently based on how she looks or presents herself, they find it weird or worthy of laughs if women actually invest time in improving said looks (by paying attention to their clothing, shopping for said clothing, worrying about hair, or the removal of hair, and so on).

It&#8217;s pretty deep-rooted in our psyche that it&#8217;s bloody well awesome to be male. We get to _expect_, almost _demand_, good looks from women while being ugly ourselves. A guy doing anything stereo-typically associated with girls? _What a wuss/sissy/how gay! _A girl doing anything stereo-typically associated with guys? _Wow! Such progress!_ (if you&#8217;re liberal) and _Look at her crossing her limits! _(if you&#8217;re a douchebag). Either way, as long as you are conforming to the male world-view of awesomeness, it&#8217;s cool bro. Err, no homo.

It&#8217;d be great if, while baying for the blood of the rapists, and while suggesting death penalties, chemical castrations, or (the latest fad on FB as I write this) stone pelting, we looked at many of the subtle ways in which educated and well-meaning people like us derail the progress towards an inclusive world. Yes, none of us are rapists, and most of us won&#8217;t hurt a fly, but when it comes to creating an environment where women (or any other marginalized group) can exist comfortably and at ease, it&#8217;s the tiny things that can make or break the deal.

&nbsp;