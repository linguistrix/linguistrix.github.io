---
title: Career Choices and Cluelessness. What after college?
author: Antariksh
type: post
date: 2014-11-13T07:41:36+00:00
url: /career-choices/
dsq_thread_id:
  - 3219858487
categories:
  - Quora Answers
  - Tuppence

---
(This was originally posted <a href="https://www.quora.com/Im-still-in-college-but-have-no-idea-what-to-do-after-completing-my-under-graduation-Is-this-normal/answer/Antariksh-Bothale" target="_blank">here</a>, as a reply to the question _&#8220;<span class="link_text">I&#8217;m still in college, but have no idea what to do after completing my under-graduation. Is this normal?&#8221;</span>_)

When people write their SOP (Statement of Purpose) while applying to graduate school or jobs, they write sentences like

> &#8220;After completing my project in #FancyTopicName working with Prof. #BigShot, I decided to do an internship at #PrestigiousMNC so that I could apply my theoretical knowledge to real world problems and gain experience of the corporate environment&#8221;

While writing SoPs, people talk as if their life path was perfectly charted out in advance, complete with Gantt Charts and Key Deliverables. You&#8217;d get the impression that everything they did was carefully choreographed and optimized for best performance. I am sure there exist a few such people who are blessed with both remarkable clarity and remarkable luck, but for most of us, this is usually not the case.

People in college do usually have a (very) broad idea of what they like, and many have a general desire to do well and be successful, but most of them keep exploring, finding opportunities and making the most of the ones they get, and it is only in retrospect that the dots connect.

You could consider doing the following to help your search and to guide your career choices

  * **Don&#8217;t be idle**. Keep experimenting / enhancing yourself. If something interests you, try to focus on strengthening your profile in it. Do extra courses or try to work on a project with a professor, read up about it or talk to others who are pursuing it&#8230; Nowadays it&#8217;s fairly easy to pick up new talents or skills if you really want to.
  * **Maintain good academic standing**. A lot of things that I mentioned in the first point would be easier to access if you maintain good academic standing. Especially in the beginning, when you don&#8217;t have specific experience, you might get good opportunities purely based on your grades / CPI. These will then help you gain more experience. One leads on to another. Like it or not, for the most part, CPI is not an unreasonable metric to judge the ability to put in hard work and persevere.
  * **Look all around.** At IITB, for instance, I&#8217;ve come across people doing all kinds of things, from the run-of-the-mill to the obscure, and often succeeding in it. Watching all these varied people engaged in a motley bunch of things is useful in two ways: It lets you know the kind of options you have, and it also shows you that those options are feasible. Use this to tell yourself that there&#8217;s a lot you can do, but obviously do not limit yourself to what has already been done.

The problem with people with stereo-typically &#8216;good&#8217; profiles is that life often does not take their decisions for them through rejection. It&#8217;s easy to decide when you have just 1-2 viable options; it&#8217;s tougher when you have 10 of them. Try not to get overwhelmed by them, and instead try to derive a sense of security or comfort from them. As for absolute clarity about what you want to do, well&#8230; that may never come. If it does for you, consider yourself very fortunate.