---
title: Khoon Chala
author: Antariksh
type: post
date: 2008-09-24T09:09:00+00:00
url: /khoon-chala/
blogger_blog:
  - antarikshspeaks.blogspot.com
blogger_author:
  - Antariksh Bothale
blogger_permalink:
  - /2008/09/khoon-chala.html
dsq_thread_id:
  - 1130171244
seo_follow:
  - 'false'
seo_noindex:
  - 'false'
categories:
  - This Life

---
> मी आज रक्तदान केले&#8230; ह्याचा अभिमान वाटतो : I donated blood today. It feels great.

That&#8217;s what the shining red and white badge said. When [MoodI][1] organised Khoon Chala, the blood donation campaign, it was something I appreciated whole-heartedly, but something I was equally sure I didn&#8217;t want to be a part of.

I don&#8217;t know why I had an inhibition in the first place, but I had pretty much decided I won&#8217;t go for it, despite it taking place in my hostel lounge. By the time it ended though, I was pretty much regretting having not donated blood.

Anyhow, when, on 23rd, the camp was again set up in H3, I decided to go for it. The kind guys asked me to fill up a form and forwarded me to the Doctor, who enquired about my disease history in the past year, which turned out to be satisfactory for the situation. From there, it was on to the temporary beds they had set up. He asked me to look away, and I felt something piercing my arm (obviously, now), something being stuck, and that was all. He said I could look now. I thought the donation procedure was over, something that was just pure scary. I mean, if that guy could take out 350 ml blood from my body in a matter of 5 seconds, it was indeed something to be horrified about. Thankfully though, the process had just started, and I felt real stupid for thinking otherwise. Anyhow, the entire procedure took about 10 minutes, with blood slowly getting collected in the standard plastic container (it contains anti-coagulant solution and was kept on one of those kitchen balances, to keep track of the weight). I was asked to lie down straight and hold a rubber ball in my hand, which I was supposed to pump to facilitate blood flow. After chatting with the guy for sometime, I found it best to listen to music while the Khoon Chalaa.

All in all, it was pretty copy-book style, and after the bag was full, he asked me to continue lying down with my legs bent close to my body (so that the brain gets sufficient blood). Some blood oozed out from the prick, but after some time, it was all pretty patched up.

[<img class="aligncenter" alt="" src="http://i2.wp.com/1.bp.blogspot.com/_Fv7z9hSDLyU/SNoLURKbInI/AAAAAAAAAPs/qGr1dkdTj74/s320/Blood.png" border="0" data-recalc-dims="1" />][2]

It was time for Tea and Biscuits, and I happily munched on a packet of ParleG. In the meanwhile, I got my certificate and blood donation card (along with the badge I could flaunt), which mentioned that I could donate blood again after three months. That card also enables me to claim blood in case I need it in the future.

The whole thing was done very nicely, and you do get a pleasant feeling of satisfaction and happiness. The folder that they gave talked about how Human blood cannot be synthesized in the Laboratory and how there is a great deficit of blood which leads to many deaths which could have been prevented.

The blood loss is corrected in 24-48 hours (in volume) and the RBC deficit is filled up in about 56 days. Some people believe that donation actually stimulates Bone Marrow to produce new cells, which leads to a cleansing effect, but all concur that Donation does not cause any harm.

Do donate blood if you get the chance.

EDIT: I read on the Internet that blood has a shelf life of about 35 days, something I was quite unaware of. But, the demand for blood is so high that no unit actually reaches expiration date. Puts the whole thing in perspective, doesn&#8217;t it?

 [1]: http://www.moodi.org/
 [2]: http://i1.wp.com/1.bp.blogspot.com/_Fv7z9hSDLyU/SNoLURKbInI/AAAAAAAAAPs/qGr1dkdTj74/s1600-h/Blood.png