---
title: What makes a rich summer experience?
author: Antariksh
type: post
date: 2012-07-30T14:50:02+00:00
url: /what-makes-a-rich-summer-experience/
seo_follow:
  - 'false'
seo_noindex:
  - 'false'
dsq_thread_id:
  - 785654097
categories:
  - Quora Answers

---
I [answered a question][1] on Quora about what makes for a rich summer experience for an undergraduate student in science and technology, and am reproducing it here:

An ideal summer experience would of course be a mix of all the elements you mentioned, but since it&#8217;s unlikely that you&#8217;ll get them all in one summer, I will propose a three summer plan.

When deciding what to do over the summer, the primary concern students have is the utility they would gain out of their summer experience. This is usually measured in terms of the employment opportunities it would open, or the _resume-value_ of the activity. Without assuming either extremes (do exactly what you want v/s do exactly what you have to), I&#8217;ll give a three-summer plan for an average undergraduate.

**First Summer**

Spending 3 months at home doing nothing is overrated. Get out and do something! Pursue one of your interests as much as you can. Try to get good at it. Nothing kills as much as mediocrity. Apart from other things, start exploring the internet. The Science and Math you learnt in the past 2–3 years have mostly outlived their utility. Read up humor, politics, technology. It&#8217;s time to become more aware of the world.

Examples of the kinds of things you could do (the list is far from exhaustive):

  * Learn to play a musical instrument. Well. Try to reach the level where you can play for your hostel or can have informal jam sessions with friends
  * Learn dancing. Not just your friendly neighborhood _baaraat dance_ with limbs flapping around but also various dance forms, such as Salsa or Tango or whatever
  * Learn a language. Human Language (you can pick up programming languages during the semester; getting good at programming is more important than learning programming languages anyhow). Preferably, do one of those intensive courses where you can learn a lot in a short period by ramping up the pace. You have more free hours per day. Use them. Don&#8217;t learn it for the heck of it. See, hear, feel it. Practise it. Try to sound as close to native as possible.
  * Do a short course in a field that interests you but is completely different from your major. Explore that field and see whether you want to pursue it further or that you are happy with just a one-summer-stand.
  * Explore the professional side of a hobby. A junior of mine interned with a professional photographer. Work with artists, writers, actors, whoever. Another junior interned with the Times of India.

**Second Summer**

Try to spend it abroad. I won&#8217;t go into the already over-explored dynamics of securing such an opportunity, but I would definitely stress on its importance.

GO! EXPLORE! LEARN!

When you&#8217;re abroad, soak in everything. Travel widely, meet people and listen to their views and opinions. It is not necessary to offer one yourself or get into pointless debates. You aren&#8217;t there to prove a point; you are there to listen to theirs.

Go with an open mind, getting rid of your pre-conceived notions of &#8216;good&#8217; and &#8216;bad&#8217;. This is the first real step you will take towards becoming progressive. You don&#8217;t know what&#8217;s wrong with yourself until you see others doing things differently. We continue to be a largely intolerant society even when things such as the internet and other forms of mass-media and easy and relatively cheap international transport have brought people and ideas closer than ever before. **Lead the change!**

**Third Summer**

Try to work in a corporate environment. Keep sniffing around to figure out how things work in such a place. The dynamics are bound to be different. While the exact experience you have would depend largely on where you work, some motifs will be common. Assimilate them all. Look out for stuff like office politics or the dynamics of work and credit allocation. Life looks a bit unfair? You got that right.

 [1]: http://www.quora.com/Indian-Institutes-of-Technology/For-an-undergrad-student-in-science-engineering-what-makes-a-rich-summer-experience/answer/Antariksh-Bothale