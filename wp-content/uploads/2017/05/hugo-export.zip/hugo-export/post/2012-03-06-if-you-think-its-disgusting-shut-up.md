---
title: If you think it’s disgusting, too bad for you.
author: Antariksh
type: post
date: 2012-03-05T19:40:41+00:00
url: /if-you-think-its-disgusting-shut-up/
s2mail:
  - yes
dsq_thread_id:
  - 785875785
seo_follow:
  - 'false'
seo_noindex:
  - 'false'
categories:
  - Articles
tags:
  - 377
  - bullying
  - gay
  - homosexuality
  - india
  - malhotra
  - non-vegetarian
  - non-vegetarianism
  - sex
  - sexuality
  - supreme court
  - vegetarian
  - vegetarianism

---
Harish showed me an interesting article. It talks about 10 food items from around the world which are considered delicacies in their respective areas, but which would be perceived as highly disgusting by people from almost everywhere else, even the most battle-hardened non-vegetarians. In that list are things like maggot-infested cheese and bat-paste, enough to make the toughest of us squeamish.

In other news, the highest court of the country spent the last month discussing whether Section 377 of the Indian Penal Code (the word Penal there never fails to amuse me, and it&#8217;s particularly funny when you are discussing 377), which criminalizes unnatural sexual activity, is constitutional, or, as I like to put it, &#8220;whether it makes any fucking sense&#8221;.

Many people seem to feel that Section 377 is about homosexuality, but it’s not. While one obvious implication of the law is indeed that gay people are harassed by the police (not that you need to be gay to be harassed by the police; being a rape victim works just as well if not better), the law basically criminalizes instances of consensual sex based on whether they are against the ‘order of nature’. Countless people have pointed out that several &#8216;acceptable&#8217; heterosexual activities can also technically be penalized under the ambit of 377, so wide and &#8216;general&#8217; is this Neanderthal law. Here, I assume that most people don&#8217;t seem to mind anything as long as it goes on between a man and a woman behind closed doors after they have delivered the stipulated number of babies for the rest of the family to busy itself with.

And how do you define &#8216;natural&#8217; anyway? Is wearing clothes natural? A lot of animal species have sex forcibly. Does that make rape natural and correct? Male members of many species often fight to death to win a female. Does that make killing for love natural? The black widow spider eats its mate after sex. Would Mr. P P Malhotra, the Assistant Solicitor General who passionately spoke about nature, advise that human females follow suit? The law of nature dictates that inferior beings be removed from the gene pool in the most brutal demonstration of winner-takes-it-all. Does that mean that we shouldn’t make efforts to make lives easier for disabled people because nature doesn’t seem to care much about them?

The hopelessness of using nature as an argument to justify or refute anything is so absolute that it is surprising that &#8216;naturality&#8217; can manage to eat up so much of the Supreme Court’s time. The whole concept of civilization, of fundamental rights and of a legal system that you use to enforce these rights is quite against the fierce, blood-thirsty and no-holds-barred show that nature provides to us.

This is a common motif across several debates across the world which span a wide range of issues, from sexual activities to dietary preferences (sometimes, both at the same time). For instance, most people simply &#8216;inherit&#8217; their dietary restrictions ([non]vegetarianism), but the level of hypocrisy I often see in the whole affair is staggering. People who would eat hens, turkeys, goats, sheep, fish, lobsters and what not without any qualms might criticize someone for eating dogs or insects. Or, considering that the majority of non-vegetarians don&#8217;t mind animals being killed to be served on their plate, it is funny that the same people suddenly find bestiality &#8216;wrong&#8217;. I find bestiality disgusting too, but, as a non-vegetarian, I don&#8217;t think I have any moral authority to consider it &#8216;wrong&#8217;, and worse, punishable, if someone indulges in sexual activity with a goat, when I wouldn&#8217;t bat an eyelid about the same goat being killed and placed on my plate to eat. What is it that makes it perfectly acceptable to brutally kill a goat but makes it wrong and illegal to put your dick in it (or its dick in you, or both—I have no frikking clue what people do with the goats they love, OK?) Whatever happens to the issue of &#8216;consent&#8217; when you put the goat’s throat under the cleaver? Last I checked, the law meted out harsher punishments for first-degree murders than it did for rape. If I did what most like to do and ported this analogy onto animals, shouldn&#8217;t it be much more heinous to kill an animal than to have sex with it?

But these issues are not likely to be solved in the near future. And that&#8217;s because we refuse to THINK. The bottom line is that most of us haven&#8217;t given and will never give a lot of thought to why we do what we do before holding on dearly to things that we love to hold on dearly to. We inherit arbitrarily drawn lines and then defend them throughout our lives instead of stepping back and questioning them with any degree of logic or reason.

Whether the experimentation be on your plate or in your bedroom, the underlying problem is the same—we assume that just because something sounds or feels disgusting to us means that it should be stopped. This was probably a tenable position a century ago when lack of adequate transport and communication facilities meant that most people were born and raised in more or less geographically (and hence, ideologically) isolated areas and when it was difficult to imagine that there could exist large-scale differences in ideas and lifestyles. It would make sense in such a society to consider deviant behaviour as wrong and punishable. But it is surprising that we continue to be a largely intolerant society even when things such as the internet and other forms of mass-media, coupled with easy and relatively cheap international transport, have brought people and ideas closer than ever before.

And this is something we imbibe right from our childhood. Anyone who&#8217;s been through the school system has usually either been on the perpetrating or receiving end of cruel ridicule or bullying just because someone was slightly deviant from established social norms. The social bonding that having these norms provides and the greater social bonding that comes from having a common enemy seem to be strong enough to make heartless beasts out of even pre-teen children.

I am not losing hope, though. The world does seem to be moving towards greater tolerance and understanding, and it is of course heartening to see that India is a part of this change too, even if a bit reluctantly. I don’t consider myself to be a champion of liberalism, but I just wish people (including me) sit back and _think_ before trying to victimize people who’re minding their own business.

(P.S. This post is not about the individual debates that I have mentioned, but about a general trend. I am bored to death of the Veg/NV debate, and this post isn&#8217;t about that, so please do not write comments about why one should or shouldn&#8217;t eat animals.)